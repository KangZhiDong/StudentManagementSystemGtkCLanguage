void on_searchfail()
{
printf("meiyouxinxidejinggaochuang");

GtkWidget* dialog;
GtkMessageType type;
gchar* message;

			message = " 没有查找到该生!\n";
			type = GTK_MESSAGE_ERROR;

dialog = gtk_message_dialog_new(NULL,GTK_DIALOG_MODAL|GTK_DIALOG_DESTROY_WITH_PARENT,type,GTK_BUTTONS_OK,message);
gtk_window_set_icon(GTK_WINDOW(dialog), create_pixbuf("123.jpg"));
gtk_window_set_position(GTK_WINDOW(dialog),GTK_WIN_POS_CENTER);
gtk_dialog_run(GTK_DIALOG(dialog));
gtk_widget_destroy(dialog);
}
