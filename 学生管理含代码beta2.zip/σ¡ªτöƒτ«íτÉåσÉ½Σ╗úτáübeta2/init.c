void init()
{head=NULL;
}
