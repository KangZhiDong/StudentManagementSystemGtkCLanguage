static GtkWidget*entry1;
static GtkWidget*entry2;
static GtkWidget*entry3;
static gchar searchzhanghao[20];

void searchid(head1)
{

   const struct id*p2;
     struct id*p1;
    char zhanghao1[20];
    printf("zhanghao：");

     strcpy(searchzhanghao,gtk_entry_get_text(GTK_ENTRY(entry1)));
strcpy(head2,gtk_entry_get_text(GTK_ENTRY(entry1)));


     const gchar*zhanghaomima=gtk_entry_get_text(GTK_ENTRY(entry2));
 printf("yaochaxunyanzhendezhanghao%s\n",searchzhanghao);

strcpy(zhanghao1,searchzhanghao);
    if(head1==NULL)
  {
    printf("\nlianbiaoshikongde!\n\n");
    return(head1);
  }
    p2=head1;

    while((strcmp(zhanghao1,p2->zhanghao)!=0)&& p2->next!=NULL)
  {
    p1=p2;
    p2=p2->next;
  }
    if((strcmp(zhanghao1,p2->zhanghao)==0))
       {
           printf("%s\n%s\n",p2->zhanghao,p2->denglumima);
           if(strcmp(zhanghaomima,p2->denglumima)==0)
           {printf("login\n");
		on_biao();
		gtk_widget_destroy(GTK_WIDGET(sub_window));}
		else
        {
          printf("failmima!\n");

		on_failuremima();
        }


       }
    else
        {printf("failzhanghao!\n");

		on_failurezhanghao();
        }
}
