void shuchuxinxi(struct student*head)
{
  struct student*p;
  int n=0;
  if(head!=NULL)
  {
    printf("\nlianbiaozhongxueshengshuju:\n");
    for(p=head;p!=NULL;p=p->next)
    {
     printf("%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n",p->num,p->name,p->sex,p->year,p->month,p->day,p->major,p->banji,p->adress,p->dorm,p->score0,p->score1,p->score2,p->xuefen);
     new_row[0]=p->num;
     new_row[1]=p->name;
     new_row[2]=p->sex;
     new_row[3]=p->year;
     new_row[4]=p->month;
     new_row[5]=p->day;
     new_row[6]=p->major;
     new_row[7]=p->banji;
     new_row[8]=p->adress;
     new_row[9]=p->dorm;
     new_row[10]=p->score0;
     new_row[11]=p->score1;
     new_row[12]=p->score2;
     new_row[13]=p->xuefen;
     n++;

     row_count++;
    gtk_clist_append(GTK_CLIST(clist),new_row);
    }
    printf("xueshengzongshu:%d\n\n",n);
  }
  else
    printf("konglianbiao!\n\n");
}
