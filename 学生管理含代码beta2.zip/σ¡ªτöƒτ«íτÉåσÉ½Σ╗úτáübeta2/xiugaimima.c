#include"searchidxiugai.c"
#include"savegaimima.c"
void on_change_delete(GtkWidget*window,GdkEvent*event,gpointer data)
{
    gtk_widget_destroy(change_window);
}



void chenggong()
{
printf("gaimimachenggong");
GtkWidget* dialog;
GtkMessageType type;
gchar* message;

			message = " 已经成功修改密码了!\n";
			type = GTK_MESSAGE_INFO;

dialog = gtk_message_dialog_new(NULL,GTK_DIALOG_MODAL|GTK_DIALOG_DESTROY_WITH_PARENT,type,GTK_BUTTONS_OK,message);
gtk_window_set_icon(GTK_WINDOW(dialog), create_pixbuf("123.jpg"));
gtk_window_set_position(GTK_WINDOW(dialog),GTK_WIN_POS_CENTER);
// j= rand()%9;
  //  image1=gtk_image_new_from_file(a[j]);
gtk_dialog_run(GTK_DIALOG(dialog));
gtk_widget_destroy(dialog);
}

void shibai()
{
printf("liugaimimashibai");
GtkWidget* dialog;
GtkMessageType type;
gchar* message;

			message = " 俩个密码不同!\n";
			type = GTK_MESSAGE_INFO;

dialog = gtk_message_dialog_new(NULL,GTK_DIALOG_MODAL|GTK_DIALOG_DESTROY_WITH_PARENT,type,GTK_BUTTONS_OK,message);
gtk_window_set_icon(GTK_WINDOW(dialog), create_pixbuf("123.jpg"));
gtk_window_set_position(GTK_WINDOW(dialog),GTK_WIN_POS_CENTER);
gtk_dialog_run(GTK_DIALOG(dialog));
gtk_widget_destroy(dialog);
}



void changemima(GtkWidget *widget, gpointer data)
{

	const gchar*mima1=gtk_entry_get_text(GTK_ENTRY(entrya));
    const gchar*mima2=gtk_entry_get_text(GTK_ENTRY(entryb));
    //const gchar*yanzheng=gtk_entry_get_text(GTK_ENTRY(entry3));
	printf("%s\n", mima1);
	printf("%s\n", mima2);
  if(strcmp(mima1, mima2) == 0)
	{
		//printf("xiu\n");
		searchidxiugai(head1);
		savegaimima(head1);
		chenggong();
		gtk_widget_destroy(GTK_WIDGET(change_window));
	}
	else
	{
		//printf("failure\n");
		shibai();
gtk_widget_destroy(GTK_WIDGET(change_window));

	}

}


GtkWidget*create_changemima_window()
{

GtkWidget* bbox;
GtkWidget* vbox;
GtkWidget* hbox;
GtkWidget* box;

//GtkWidget* label;
GtkWidget* label1;
GtkWidget* label2;


GtkWidget*box1;
GtkWidget*box2;

GtkWidget* window;
GtkWidget* sep;
GtkWidget* button;
GtkWidget* image;
window=gtk_window_new(GTK_WINDOW_TOPLEVEL);
gtk_window_set_title(GTK_WINDOW(window),"修改密码");
g_signal_connect(G_OBJECT(window),"delete_event",G_CALLBACK(on_change_delete),NULL);
gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_CENTER);
gtk_container_set_border_width(GTK_CONTAINER(window),20);
    gtk_window_set_icon(GTK_WINDOW(window), create_pixbuf("123.jpg"));


box=gtk_vbox_new(FALSE,0);
    gtk_container_add(GTK_CONTAINER(window),box);

    box1=gtk_hbox_new(FALSE,0);
    gtk_box_pack_start(GTK_BOX(box),box1,FALSE,FALSE,5);
    box2=gtk_hbox_new(FALSE,0);
    gtk_box_pack_start(GTK_BOX(box),box2,FALSE,FALSE,5);



label1=gtk_label_new("           输入新密码:");    //("用户名:");
    entrya=gtk_entry_new();
    gtk_entry_set_visibility(GTK_ENTRY(entrya),FALSE);
    gtk_box_pack_start(GTK_BOX(box1),label1,FALSE,FALSE,5);
    gtk_box_pack_start(GTK_BOX(box1),entrya,FALSE,FALSE,5);

    label2=gtk_label_new("     再次确定新密码:");        // ("  密码:");
    entryb=gtk_entry_new();
    gtk_entry_set_visibility(GTK_ENTRY(entryb),FALSE);
    gtk_box_pack_start(GTK_BOX(box2),label2,FALSE,FALSE,5);
    gtk_box_pack_start(GTK_BOX(box2),entryb,FALSE,FALSE,5);





sep = gtk_hseparator_new();
gtk_box_pack_start(GTK_BOX(box),sep,FALSE,FALSE,5);
bbox = gtk_hbutton_box_new();
gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox),GTK_BUTTONBOX_EDGE);
gtk_box_pack_start(GTK_BOX(box),bbox,FALSE,FALSE,5);
button = gtk_button_new_from_stock(GTK_STOCK_OK);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,25);
/* gchar*mima1=gtk_entry_get_text(GTK_ENTRY(entrya));
gchar*mima2=gtk_entry_get_text(GTK_ENTRY(entryb));
    printf("%s\n", mima1);
	printf("%s\n", mima2);

   if(strcmp(mima1, mima2) == 0)
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(chenggong),NULL);
else
    g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(shibai),NULL);*/
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(changemima),NULL);
g_signal_connect(G_OBJECT(button),"released",G_CALLBACK(on_change_delete),NULL);
button = gtk_button_new_from_stock(GTK_STOCK_CANCEL);
g_signal_connect(GTK_OBJECT(button),"clicked",G_CALLBACK(on_change_delete),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,35);
gtk_widget_show_all(window);
return window;
}



void on_change(GtkButton*button,gpointer data)
{
 change_window=create_changemima_window();
 gtk_widget_show(change_window);
}
