static GtkWidget*search_window;
static GtkWidget *entry_search;
static gchar *searchstunum;


void searchnum(head)
{
   const struct student*p2;
     struct student*p1;
    char *num1;
    printf("shuruxuehao：");

     searchstunum=gtk_entry_get_text(GTK_ENTRY(entry_search));
 printf("%s",searchstunum);
num1=searchstunum;
    if(head==NULL)
  {
    printf("\nlianbiaoshikongde!\n\n");
    return(head);
  }
    p2=head;
    while((strcmp(num1,p2->num)!=0)&& p2->next!=NULL)
  {
    p1=p2;
    p2=p2->next;
  }
    if((strcmp(num1,p2->num)==0))
       {
           printf("%s\n%s\n%c\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n",p2->num,p2->name,p2->sex,p2->year,p2->month,p2->day,p2->major,p2->banji,p2->adress,p2->dorm,p2->score0,p2->score1,p2->score2,p2->xuefen);
          chaxunxinxi(p2);


       }
    else
        {printf("\meiyouzhegexuesheng!\n");
        on_searchfail();
        }
}
