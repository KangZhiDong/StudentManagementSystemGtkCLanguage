static int  sortbynumchenggong=1;

struct student*sortbynum(struct student*head)
{
   int i=0;
   struct student *p,*q,*t,*h1;
   h1=head->next;
   head->next=NULL;
   while(h1!=NULL)
   {
      t=h1;
      h1=h1->next;
      p=head;
      q=head;
      while(p!=NULL&&strcmp(t->num,p->num)>0)
      {
	 q=p;
	 p=p->next;
      }
      if(p==q)
      {
	 t->next=p;
	 head=t;
      }
      else
      {
	 t->next=p;
	 q->next=t;
      }
   }

   printf("sort sucess!!!\n");
   return head;
}
