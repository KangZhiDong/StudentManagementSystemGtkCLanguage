


void on_delnum_delete(GtkWidget*window,GdkEvent*event,gpointer data)
{
    gtk_widget_destroy(delnum_window);
}

void on_delnumqueding()
{
printf("kaishishanchushuju");
head=delbynum(head);
shuchu(head);
printf("%d",delnumchenggong);
if(delnumchenggong==1)
{GtkWidget* dialog;
GtkMessageType type;
gchar* message;

			message = " 已经成功删除该生!\n";
			type = GTK_MESSAGE_INFO;

dialog = gtk_message_dialog_new(NULL,GTK_DIALOG_MODAL|GTK_DIALOG_DESTROY_WITH_PARENT,type,GTK_BUTTONS_OK,message);
gtk_window_set_icon(GTK_WINDOW(dialog), create_pixbuf("123.jpg"));
gtk_window_set_position(GTK_WINDOW(dialog),GTK_WIN_POS_CENTER);
gtk_dialog_run(GTK_DIALOG(dialog));
gtk_widget_destroy(dialog);}

else
{
printf("shanchushibaichangkou");

GtkWidget* dialog;
GtkMessageType type;
gchar* message;

			message = " 删除该生失败!\n";
			type = GTK_MESSAGE_ERROR;

dialog = gtk_message_dialog_new(NULL,GTK_DIALOG_MODAL|GTK_DIALOG_DESTROY_WITH_PARENT,type,GTK_BUTTONS_OK,message);
gtk_window_set_icon(GTK_WINDOW(dialog), create_pixbuf("123.jpg"));
gtk_window_set_position(GTK_WINDOW(dialog),GTK_WIN_POS_CENTER);
gtk_dialog_run(GTK_DIALOG(dialog));
gtk_widget_destroy(dialog);
}
}


GtkWidget*create_delnum_window()
{
GtkWidget* bbox;
GtkWidget* vbox;
GtkWidget* label;
GtkWidget* window;
GtkWidget* sep;
GtkWidget* button;
GtkWidget* table;
window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
gtk_window_set_icon(GTK_WINDOW(window), create_pixbuf("123.jpg"));
g_signal_connect(G_OBJECT(window),"delete_event",G_CALLBACK(on_delnum_delete),window);
gtk_window_set_title(GTK_WINDOW(window),"按学号查询删除");
gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_CENTER);
gtk_container_set_border_width(GTK_CONTAINER(window),10);
vbox = gtk_vbox_new(FALSE,0);
gtk_container_add(GTK_CONTAINER(window),vbox);
table = gtk_table_new(5,2,FALSE);
gtk_box_pack_start(GTK_BOX(vbox),table,FALSE,FALSE,5);
label = gtk_label_new("输入你要学生学生的学号:");
gtk_table_attach_defaults(GTK_TABLE(table),label,0,1,0,1);
entry_delnum = gtk_entry_new();
gtk_table_attach_defaults(GTK_TABLE(table),entry_delnum,1,2,0,1);
sep = gtk_hseparator_new();
gtk_box_pack_start(GTK_BOX(vbox),sep,FALSE,FALSE,5);
bbox = gtk_hbutton_box_new();
gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox),GTK_BUTTONBOX_EDGE);
gtk_box_pack_start(GTK_BOX(vbox),bbox,FALSE,FALSE,5);
button = gtk_button_new_from_stock(GTK_STOCK_FIND);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,25);

g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_delnumqueding),NULL);
g_signal_connect(G_OBJECT(button),"released",G_CALLBACK(on_delnum_delete),NULL);
button = gtk_button_new_from_stock(GTK_STOCK_CANCEL);
g_signal_connect(GTK_OBJECT(button),"clicked",G_CALLBACK(on_delnum_delete),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,35);
gtk_widget_show_all(window);
return window;
}


void on_delnum(GtkButton*button,gpointer data)
{
 delnum_window=create_delnum_window();
 gtk_widget_show(delnum_window);
}
