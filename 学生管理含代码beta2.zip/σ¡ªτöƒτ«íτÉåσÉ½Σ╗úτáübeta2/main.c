#include <stdlib.h>
#include<stdio.h>
#include <gtk/gtk.h>
#include<string.h>


GdkPixbuf *create_pixbuf(const gchar* filename)
{
 GdkPixbuf *pixbuf;
 GError *error = NULL;
 pixbuf = gdk_pixbuf_new_from_file(filename, &error);
 if(!pixbuf) {
 fprintf(stderr, "%s\n", error->message);
 g_error_free(error);
 }
 return pixbuf;
}

static GtkWidget*main_window;
static GtkWidget*sub_window;
static GtkWidget*about_window;
static GtkWidget*biao_window;
static int a=0;

int tongji=0;

 struct  id
{
    char zhanghao[20];
    char denglumima[20];
    struct id*next;
};
struct id*head1=NULL;
char *head2[20];
#include"savemima.c"

#include"mima.c"

#include"about.c"
#include"denglu.c"
#include"outputmima.c"
#include"loadmima.c"




int main(int argc,char*argv[])
{
    gtk_init(&argc,&argv);
 main_window=create_main_windowx();
 gtk_widget_show(main_window);
 head1=loadmima();


 gtk_main();
 return 0;}

