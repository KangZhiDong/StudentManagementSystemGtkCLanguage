struct id*loadmima()
{
    struct id*p;
    struct id*p1;
    struct id*p3;
    struct id*p4;
    int n=0,i=0,j=0;

    FILE*fp1;
    if((fp1=fopen("mima.txt","r"))==NULL)
    {
        printf("bunnengdakaimima!\n");
        exit(0);
    }

    else
     {

        head1 =(struct id *)malloc(sizeof(struct id));
        if(fread(head1,sizeof(struct id),1,fp1)!=1)

            {printf("meiyoumimakeyiduqu!\n\n");
            head1=NULL;
            shuchumima(head1);
            return head1;}

        p=head1;
        n++;
        while(!feof(fp1))
        {
          p1= (struct id *)malloc(sizeof(struct id));
          fread(p1,sizeof(struct id),1,fp1);
          p->next=p1;
          p=p1;
          n++;
        }
        p->next=NULL;
     }
    n--;
    for(p3=head1,i=0;p3!=NULL;p3=p3->next) i++;
     for(j=0,p4=head1;j<i-2;j++)
     {
         p4=p4->next;
     }
     p4->next=NULL;



printf("ciciduqumima%d\n\n",n);
shuchumima(head1);

    fclose(fp1);
    return head1;
}
