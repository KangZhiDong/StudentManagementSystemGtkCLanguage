#include"insert.c"

void on_zhuce_delete(GtkWidget*window,GdkEvent*event,gpointer data)
{
    gtk_widget_destroy(zhuce_window);
}



void chenggong1()
{

printf("zhucechenggongtishi");
shuchumima(head1);
GtkWidget* dialog;
GtkMessageType type;
gchar* message;

			message = " 已经成功注册了!\n";
			type = GTK_MESSAGE_INFO;

dialog = gtk_message_dialog_new(NULL,GTK_DIALOG_MODAL|GTK_DIALOG_DESTROY_WITH_PARENT,type,GTK_BUTTONS_OK,message);
gtk_window_set_icon(GTK_WINDOW(dialog), create_pixbuf("123.jpg"));
gtk_window_set_position(GTK_WINDOW(dialog),GTK_WIN_POS_CENTER);
gtk_dialog_run(GTK_DIALOG(dialog));
gtk_widget_destroy(dialog);
}

void shibai1()
{
printf("zhuceshibaitishi");
GtkWidget* dialog;
GtkMessageType type;
gchar* message;

			message = " 注册失败!\n";
			type = GTK_MESSAGE_INFO;

dialog = gtk_message_dialog_new(NULL,GTK_DIALOG_MODAL|GTK_DIALOG_DESTROY_WITH_PARENT,type,GTK_BUTTONS_OK,message);
gtk_window_set_icon(GTK_WINDOW(dialog), create_pixbuf("123.jpg"));
gtk_window_set_position(GTK_WINDOW(dialog),GTK_WIN_POS_CENTER);
gtk_dialog_run(GTK_DIALOG(dialog));
gtk_widget_destroy(dialog);
}



void zhuce(GtkWidget *widget, gpointer data)
{

	const gchar*mima1=gtk_entry_get_text(GTK_ENTRY(entrym));
    const gchar*mima2=gtk_entry_get_text(GTK_ENTRY(entryn));

	printf("%syanzhengshuru\n", mima1);
	printf("%syanzhengshuru\n", mima2);

	 if(strcmp(mima1, mima2) == 0)
	{
        insert(head1);
        savemima(head1);
		chenggong1();
		gtk_widget_destroy(GTK_WIDGET(zhuce_window));
	}
	else
	{

		shibai1();
gtk_widget_destroy(GTK_WIDGET(zhuce_window));

	}

}


GtkWidget*create_zhuce_window()
{

GtkWidget* bbox;
GtkWidget* vbox;
GtkWidget* hbox;
GtkWidget* box;

GtkWidget* label0;
GtkWidget* label1;
GtkWidget* label2;
GtkWidget*box0;
GtkWidget*box1;
GtkWidget*box2;

GtkWidget* window;
GtkWidget* sep;
GtkWidget* button;
GtkWidget* image;
window=gtk_window_new(GTK_WINDOW_TOPLEVEL);
gtk_window_set_title(GTK_WINDOW(window),"注册新用户");
g_signal_connect(G_OBJECT(window),"delete_event",G_CALLBACK(on_zhuce_delete),NULL);
gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_CENTER);
gtk_container_set_border_width(GTK_CONTAINER(window),20);
    gtk_window_set_icon(GTK_WINDOW(window), create_pixbuf("123.jpg"));


box=gtk_vbox_new(FALSE,0);
    gtk_container_add(GTK_CONTAINER(window),box);
  box0=gtk_hbox_new(FALSE,0);
    gtk_box_pack_start(GTK_BOX(box),box0,FALSE,FALSE,5);

    box1=gtk_hbox_new(FALSE,0);
    gtk_box_pack_start(GTK_BOX(box),box1,FALSE,FALSE,5);
    box2=gtk_hbox_new(FALSE,0);
    gtk_box_pack_start(GTK_BOX(box),box2,FALSE,FALSE,5);


label0=gtk_label_new("                    学号:");    //("用户名:");
    entryx=gtk_entry_new();

    gtk_box_pack_start(GTK_BOX(box0),label0,FALSE,FALSE,5);
    gtk_box_pack_start(GTK_BOX(box0),entryx,FALSE,FALSE,5);




label1=gtk_label_new("           输入新密码:");    //("用户名:");
    entrym=gtk_entry_new();
    gtk_entry_set_visibility(GTK_ENTRY(entrym),FALSE);
    gtk_box_pack_start(GTK_BOX(box1),label1,FALSE,FALSE,5);
    gtk_box_pack_start(GTK_BOX(box1),entrym,FALSE,FALSE,5);

    label2=gtk_label_new("     再次确定新密码:");        // ("  密码:");
    entryn=gtk_entry_new();
    gtk_entry_set_visibility(GTK_ENTRY(entryn),FALSE);
    gtk_box_pack_start(GTK_BOX(box2),label2,FALSE,FALSE,5);
    gtk_box_pack_start(GTK_BOX(box2),entryn,FALSE,FALSE,5);





sep = gtk_hseparator_new();
gtk_box_pack_start(GTK_BOX(box),sep,FALSE,FALSE,5);
bbox = gtk_hbutton_box_new();
gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox),GTK_BUTTONBOX_EDGE);
gtk_box_pack_start(GTK_BOX(box),bbox,FALSE,FALSE,5);
button = gtk_button_new_from_stock(GTK_STOCK_OK);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,25);
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(zhuce),NULL);
g_signal_connect(G_OBJECT(button),"released",G_CALLBACK(on_zhuce_delete),NULL);
button = gtk_button_new_from_stock(GTK_STOCK_CANCEL);
g_signal_connect(GTK_OBJECT(button),"clicked",G_CALLBACK(on_zhuce_delete),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,35);
gtk_widget_show_all(window);
return window;
}



void on_zhuce(GtkButton*button,gpointer data)
{
 zhuce_window=create_zhuce_window();
 gtk_widget_show(zhuce_window);
}
