void shuchumima(struct id*head1)
{
  struct id*p;
  int n=0;
  if(head1!=NULL)
  {
    printf("\nshuchumimaruxia:\n");
    for(p=head1;p!=NULL;p=p->next)
    {
     printf("%s\n%s\n",p->zhanghao,p->denglumima);

     n++;
    }
    printf("mimazongshu:%d\n\n",n);
  }
  else
    printf("meiyoumimashuju!\n\n");
}
