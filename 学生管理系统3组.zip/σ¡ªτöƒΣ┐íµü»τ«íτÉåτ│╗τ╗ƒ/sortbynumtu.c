void on_sortnum()
{
printf("kaishianxuehaopaixu");
head=sortbynum(head);

if(sortbynumchenggong==1)
{
    GtkWidget* dialog;
GtkMessageType type;
gchar* message;

			message = " 已经成功按学号排序!\n";
			type = GTK_MESSAGE_INFO;

dialog = gtk_message_dialog_new(NULL,GTK_DIALOG_MODAL|GTK_DIALOG_DESTROY_WITH_PARENT,type,GTK_BUTTONS_OK,message);
gtk_window_set_icon(GTK_WINDOW(dialog), create_pixbuf("123.jpg"));
gtk_window_set_position(GTK_WINDOW(dialog),GTK_WIN_POS_CENTER);
gtk_dialog_run(GTK_DIALOG(dialog));
gtk_widget_destroy(dialog);
}
else
{

printf("xuehaopaixushibaichangkou");

GtkWidget* dialog;
GtkMessageType type;
gchar* message;

			message = " 按学号排序失败!\n";
			type = GTK_MESSAGE_ERROR;

dialog = gtk_message_dialog_new(NULL,GTK_DIALOG_MODAL|GTK_DIALOG_DESTROY_WITH_PARENT,type,GTK_BUTTONS_OK,message);
gtk_window_set_icon(GTK_WINDOW(dialog), create_pixbuf("123.jpg"));
gtk_window_set_position(GTK_WINDOW(dialog),GTK_WIN_POS_CENTER);
gtk_dialog_run(GTK_DIALOG(dialog));
gtk_widget_destroy(dialog);

}
}
