/*void quit(GtkButton *button,gpointer data)
{
    gtk_widget_destroy(data);
}*/
/////////////GtkWidget


enum{
	//ID_COLUMN,
	//TOGGLE_COLUMN,
	TEXT_COLUMN0,
	TEXT_COLUMN1,
	TEXT_COLUMN2,
	TEXT_COLUMN3,
	TEXT_COLUMN4,
	TEXT_COLUMN5,
	TEXT_COLUMN6,
	TEXT_COLUMN7,
	TEXT_COLUMN8,
	TEXT_COLUMN9,
	TEXT_COLUMN10,
	TEXT_COLUMN11,
	TEXT_COLUMN12,
	TEXT_COLUMN13,
	//TEXT_COLUMN,
	N_COLUMN
};


/*struct _listitem{
	gint id;
	const gchar *num;
	const gchar *name;
	const gchar *sex;
	const int year;
	const int month;
	const int day;
	const gchar *major;
	const gchar *banji;
	const gchar *adress;
	const gchar *dorm;
	const float score1;
	const float score2;
	const float score3;
	const float xuefen;

};*/



typedef struct _listitem ListItem;
struct _listitem{
	const gchar *text0;
	const gchar *text1;
	const gchar *text2;
	const gchar *text3;
	const gchar *text4;
	const gchar *text5;
	const gchar *text6;
	const gchar *text7;
	const gchar *text8;
	const gchar *text9;
	const gchar *text10;
	const gchar *text11;
	const gchar *text12;
	const gchar *text13;
};


ListItem t[5] = {{"1090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明"},{"090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明"},{"090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明"},{"090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明"},{"090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明"}};

//ListItem t[5] = {"1090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明2","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明","090","小明5"};


GtkListStore * create_list_model(void)
{
	GtkListStore *list_store;
	GtkTreeIter iter;
	gint i;
	list_store = gtk_list_store_new(N_COLUMN,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	shuchuxinxi(head);
	//g_convert("中国",-1,"WINDOWS-936","UTF-8",NULL,NULL,NULL);
	for(i = 0;i<2;i++)
	{
	    _(t[i].text1);
	    _(t[i].text1);

		gtk_list_store_append(list_store,&iter);
		gtk_list_store_set(list_store,&iter,TEXT_COLUMN0,t[i].text0,
						   TEXT_COLUMN1,t[i].text1,
							TEXT_COLUMN2,t[i].text2,
							TEXT_COLUMN3,t[i].text3,
							TEXT_COLUMN4,t[i].text4,
							TEXT_COLUMN5,t[i].text5,
							TEXT_COLUMN6,t[i].text6,
							TEXT_COLUMN7,t[i].text7,
							TEXT_COLUMN8,t[i].text8,
							TEXT_COLUMN9,t[i].text9,
							TEXT_COLUMN10,t[i].text10,
							TEXT_COLUMN11,t[i].text11,
							TEXT_COLUMN12,t[i].text12,
							TEXT_COLUMN13,t[i].text13,-1);
	}
	return list_store;
}

GtkWidget* create_list(GtkListStore* list_store)
{
    GtkWidget* view;
    GtkTreeModel* model;
    GtkCellRenderer* renderer;
    GtkTreeViewColumn* column;

    model = GTK_TREE_MODEL(list_store);
    view  = gtk_tree_view_new_with_model(model);
    renderer = gtk_cell_renderer_text_new();
    column = gtk_tree_view_column_new_with_attributes("      学号            ",renderer,"text",TEXT_COLUMN0,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(view),column);

    renderer = gtk_cell_renderer_text_new();
    g_object_set(G_OBJECT(renderer),"editable",TRUE,NULL);
    g_object_set (G_OBJECT (renderer),
                 "foreground", "red",
                 NULL);
                 gtk_tree_view_column_set_resizable(column,TRUE);
    column = gtk_tree_view_column_new_with_attributes("       姓名        ",renderer,"text",TEXT_COLUMN1,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(view),column);

    renderer = gtk_cell_renderer_text_new();
    g_object_set(G_OBJECT(renderer),"editable",TRUE,NULL);
    g_object_set (G_OBJECT (renderer),"foreground", "green",NULL);
    column = gtk_tree_view_column_new_with_attributes("   性别  ",renderer,"text",TEXT_COLUMN2,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(view),column);
    renderer = gtk_cell_renderer_text_new();
    g_object_set(G_OBJECT(renderer),"editable",TRUE,NULL);
    column = gtk_tree_view_column_new_with_attributes("   年份   ",renderer,"text",TEXT_COLUMN3,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(view),column);
    renderer = gtk_cell_renderer_text_new();
    g_object_set(G_OBJECT(renderer),"editable",TRUE,NULL);
    column = gtk_tree_view_column_new_with_attributes("   月份   ",renderer,"text",TEXT_COLUMN4,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(view),column);
    renderer = gtk_cell_renderer_text_new();
    g_object_set(G_OBJECT(renderer),"editable",TRUE,NULL);
    column = gtk_tree_view_column_new_with_attributes("   日   ",renderer,"text",TEXT_COLUMN5,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(view),column);
    renderer = gtk_cell_renderer_text_new();
    g_object_set(G_OBJECT(renderer),"editable",TRUE,NULL);
    column = gtk_tree_view_column_new_with_attributes("          专业        ",renderer,"text",TEXT_COLUMN6,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(view),column);
    renderer = gtk_cell_renderer_text_new();
    g_object_set(G_OBJECT(renderer),"editable",TRUE,NULL);
    column = gtk_tree_view_column_new_with_attributes("            班级           ",renderer,"text",TEXT_COLUMN7,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(view),column);
    renderer = gtk_cell_renderer_text_new();
    g_object_set(G_OBJECT(renderer),"editable",TRUE,NULL);
    column = gtk_tree_view_column_new_with_attributes("                  家庭地址                     ",renderer,"text",TEXT_COLUMN8,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(view),column);
    renderer = gtk_cell_renderer_text_new();
    g_object_set(G_OBJECT(renderer),"editable",TRUE,NULL);
    column = gtk_tree_view_column_new_with_attributes("        宿舍      ",renderer,"text",TEXT_COLUMN9,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(view),column);
    renderer = gtk_cell_renderer_text_new();
    g_object_set(G_OBJECT(renderer),"editable",TRUE,NULL);
    column = gtk_tree_view_column_new_with_attributes("    高数   ",renderer,"text",TEXT_COLUMN10,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(view),column);
    renderer = gtk_cell_renderer_text_new();
    g_object_set(G_OBJECT(renderer),"editable",TRUE,NULL);
    column = gtk_tree_view_column_new_with_attributes("    英语   ",renderer,"text",TEXT_COLUMN11,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(view),column);
    renderer = gtk_cell_renderer_text_new();
    g_object_set(G_OBJECT(renderer),"editable",TRUE,NULL);
    column = gtk_tree_view_column_new_with_attributes("    语文    ",renderer,"text",TEXT_COLUMN12,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(view),column);
    renderer = gtk_cell_renderer_text_new();
    g_object_set(G_OBJECT(renderer),"editable",TRUE,NULL);
    column = gtk_tree_view_column_new_with_attributes("     总学分    ",renderer,"text",TEXT_COLUMN13,NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(view),column);
    return view;
}

void show_list(void)
{
	GtkWidget* window;
	GtkWidget* frame;
	GtkWidget* view;
	GtkListStore* model;
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	//window=gtk_scrolled_window_new(NULL, NULL);
	//gtk_window_set_default_size(GTK_WINDOW(window),600,300);
	gtk_widget_set_size_request (window, 1250, 500);
	gtk_window_set_icon(GTK_WINDOW(window), create_pixbuf("123.jpg"));
	//g_signal_connect(G_OBJECT(window),"destroy",G_CALLBACK(gtk_main_quit),window);
	gtk_window_set_title(GTK_WINDOW(window),"学生信息管理系统");
	gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_CENTER);
	gtk_container_set_border_width(GTK_CONTAINER(window),10);
	frame = gtk_frame_new("学生信息管理                                                                                                                                    ");
	gtk_frame_set_label_align(GTK_FRAME(frame),1.0,0);
	gtk_container_add(GTK_CONTAINER(window),frame);
	model = create_list_model();
	view = create_list(model);
	gtk_container_add(GTK_CONTAINER(frame),view);
	gtk_widget_show_all(window);
}


	/*	vbox = gtk_vbox_new(FALSE,0);
		gtk_container_add(GTK_CONTAINER(window),vbox);


		button = gtk_button_new_with_label("显示学生信息");
		gtk_box_pack_start(GTK_BOX(vbox),button,FALSE,FALSE,10);
		g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(xianshi),NULL);
		button = gtk_button_new_with_label("修改密码");
		gtk_box_pack_start(GTK_BOX(vbox),button,FALSE,FALSE,0);
		g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_change),NULL);
		button = gtk_button_new_with_label("载入数据");
		gtk_box_pack_start(GTK_BOX(vbox),button,FALSE,FALSE,0);
		g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_load),NULL);
		button = gtk_button_new_with_label("从文件夹中添加数据");
		gtk_box_pack_start(GTK_BOX(vbox),button,FALSE,FALSE,0);
		g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_loadfile),NULL);
		button = gtk_button_new_with_label("添加学生数据");
		gtk_box_pack_start(GTK_BOX(vbox),button,FALSE,FALSE,0);
		g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(append_row),NULL);
		button = gtk_button_new_with_label("按学号查找数据");
		gtk_box_pack_start(GTK_BOX(vbox),button,FALSE,FALSE,0);
		g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_search),NULL);
		button = gtk_button_new_with_label("按名字查找数据");
		gtk_box_pack_start(GTK_BOX(vbox),button,FALSE,FALSE,0);
		g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_search1),NULL);

		button = gtk_button_new_with_label("删除学生(by学号)");
		gtk_box_pack_start(GTK_BOX(vbox),button,FALSE,FALSE,0);
		g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_delnum),NULL);
		button = gtk_button_new_with_label("删除学生(by名字)");
		gtk_box_pack_start(GTK_BOX(vbox),button,FALSE,FALSE,0);
		g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_delname),NULL);
		button = gtk_button_new_with_label("按学号排序");
		gtk_box_pack_start(GTK_BOX(vbox),button,FALSE,FALSE,0);
		g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_sortnum),NULL);
		button = gtk_button_new_with_label("按名字排序");
		gtk_box_pack_start(GTK_BOX(vbox),button,FALSE,FALSE,0);
		g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_sortname),NULL);
		button = gtk_button_new_with_label("保存数据");
		gtk_box_pack_start(GTK_BOX(vbox),button,FALSE,FALSE,0);
		g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_save),NULL);
		button = gtk_button_new_with_label("另存数据");
		gtk_box_pack_start(GTK_BOX(vbox),button,FALSE,FALSE,0);
		g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_saveas),NULL);
		button = gtk_button_new_with_label("清空数据");
		gtk_box_pack_start(GTK_BOX(vbox),button,FALSE,FALSE,0);
		g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(init),NULL);
		button = gtk_button_new_with_label("退出系统");
		gtk_box_pack_start(GTK_BOX(vbox),button,FALSE,FALSE,0);
		g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_quit),window);*/
