
static GtkWidget*quit_window;
void on_quit_delete(GtkWidget*window,GdkEvent*event,gpointer data)
{
    gtk_widget_destroy(quit_window);
}



void quit(GtkButton *button,gpointer data)
{
    gtk_widget_destroy(data);
}


GtkWidget*create_quit_window()
{
GtkWidget* bbox;
GtkWidget* vbox;
GtkWidget* hbox;

GtkWidget* label;
GtkWidget* window;
GtkWidget* sep;
GtkWidget* button;
GtkWidget* image;
window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
gtk_window_set_icon(GTK_WINDOW(window), create_pixbuf("123.jpg"));
g_signal_connect(G_OBJECT(window),"delete_event",G_CALLBACK(on_quit_delete),NULL);
vbox=gtk_vbox_new(FALSE,0);
gtk_container_add(GTK_CONTAINER(window),vbox);
hbox=gtk_hbox_new(FALSE,0);
gtk_box_pack_start(GTK_BOX(vbox),hbox,FALSE,FALSE,5);
image=gtk_image_new_from_stock(GTK_STOCK_DIALOG_ERROR,GTK_ICON_SIZE_DIALOG);
gtk_box_pack_start(GTK_BOX(hbox),image,FALSE,FALSE,5);
label=gtk_label_new("确定退出？注意保存信息哦！");
gtk_box_pack_start(GTK_BOX(hbox),label,FALSE,FALSE,5);

sep = gtk_hseparator_new();
gtk_box_pack_start(GTK_BOX(vbox),sep,FALSE,FALSE,5);
bbox = gtk_hbutton_box_new();
gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox),GTK_BUTTONBOX_EDGE);
gtk_box_pack_start(GTK_BOX(vbox),bbox,FALSE,FALSE,5);
button = gtk_button_new_from_stock(GTK_STOCK_OK);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,25);
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(quit),biao_window);
g_signal_connect(G_OBJECT(button),"released",G_CALLBACK(quit),window);
button = gtk_button_new_from_stock(GTK_STOCK_CANCEL);
g_signal_connect(GTK_OBJECT(button),"clicked",G_CALLBACK(on_quit_delete),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,35);
gtk_widget_show_all(window);
return window;
}

void on_quit(GtkButton*button,gpointer data)
{
    printf("tuichu");
 quit_window=create_quit_window();
 gtk_widget_show(quit_window);
}

