static GtkWidget*delnum_window;
static GtkWidget *entry_delnum;
static int delnumchenggong=1;

struct student*delbynum(struct student*head)
{
  struct student*p2;
  struct student*p1;

  const gchar*num1=gtk_entry_get_text(GTK_ENTRY(entry_delnum));

  if(head==NULL)
  {
    printf("\nlianbiaoshikongde!\n\n");
    delnumchenggong=0;
    return(head);

  }
  p2=head;
  while((strcmp(num1,p2->num)!=0)&& p2->next!=NULL)
  {
    p1=p2;
    p2=p2->next;
  }
  if((strcmp(num1,p2->num)==0))
  {
    if(p2==head)
     head=p2->next;
    else
     p1->next=p2->next;
     free(p2);
     printf("shanchule%sxuesheng!\n\n",num1);
  }
  else
    {printf("\ngaixueshengbucunzai!\n\n");
    delnumchenggong=0;
    }
  return(head);
}
