#include<gtk/gtk.h>

  struct student
{
    char num[20];
    char name[20];
    char sex[20];
    char year[20];
    char month[20];
    char  day[20];
    char major[20];
    char banji[20];
    char adress[20];
    char dorm[20];
    char  score0[20];
    char  score1[20];
    char  score2[20];
    char xuefen[20];
    struct student*next;
};
struct student*head=NULL;



char *_(char *string)
{
    return(g_locale_from_utf8(string, -1, NULL, NULL, NULL));
}

void on_biao_delete(GtkWidget*window,GdkEvent*event,gpointer data)
{
    gtk_widget_destroy(biao_window);
}

static gchar* titles[14]={"      学号            ","       姓名        ","   性别  ","   年份   ","   月份   ","   日   ","          专业        ","            班级           ","                  家庭地址                     ","        宿舍      ","    语文   ","   数学   ","    英语   ","   学分  "};
const gchar *new_row[14];
const gchar *new_row1[14];
static GtkWidget *clist2;
static GtkWidget *clist;
static GtkWidget *add_win;
static GtkWidget *xianshi_win;
static GtkWidget *xianshichaxun_win;
static GtkWidget *xianshichaxun_win1;
static GtkWidget *entry_num;
static GtkWidget *entry_name;
static GtkWidget *entry_sex;
static GtkWidget *entry_year;
static GtkWidget *entry_month;
static GtkWidget *entry_day;
static GtkWidget *entry_major;
static GtkWidget *entry_banji;
static GtkWidget *entry_adress;
static GtkWidget *entry_dorm;
static GtkWidget *entry_score1;
static GtkWidget *entry_score2;
static GtkWidget *entry_score3;
static GtkWidget *entry_xuefen;
static GtkWidget *entry_lujin;
gint current_row = 0;
gint current_row1 = 0;
gint row_count = 0;
gint row_count1 = 0;


#include"init.c"
#include"output.c"
#include"input.c"
#include"delbynum.c"
#include"delbynumtu.c"
#include"delbyname.c"
#include"delbynametu.c"
#include"save.c"
#include"savetu.c"
#include"saveas.c"
#include"saveastu.c"
#include"quittu.c"
#include"loadfromfile.c"
#include"loadfromfiletu.c"
#include"loadnew.c"
#include"loadtu.c"
#include"xiugaimima.c"
#include"outputxinxi.c"
#include"outputchaxun.c"
#include"chaxuntu.c"
#include"chaxuntu1.c"
#include"meiyouxinxi.c"
#include"searchnum.c"
#include"searchnumtu.c"
#include"searchname.c"
#include"searchnametu.c"
#include"sortbynum.c"
#include"sortbynumtu.c"
#include"sortbyname.c"
#include"sortbynametu.c"
#include"xianshi.c"


	GtkWidget* create_biao_window()
	{
		GtkWidget* window,*button;
		GtkWidget *table;
		GtkWidget *frame;
		window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
		gtk_window_set_icon(GTK_WINDOW(window), create_pixbuf("123.jpg"));
		gtk_window_set_title(GTK_WINDOW(window),"学生管理系统");
		gtk_window_set_default_size(GTK_WINDOW(window),500,400);
		gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_CENTER);
		gtk_container_set_border_width(GTK_CONTAINER(window),20);
		g_signal_connect(G_OBJECT(window),"delete_event",G_CALLBACK(gtk_main_quit),NULL);
		frame = gtk_frame_new("以下功能:");
		gtk_container_add(GTK_CONTAINER(window),frame);


		table= gtk_table_new(4,4,FALSE);
		gtk_container_set_border_width(GTK_CONTAINER(table),10);
		gtk_table_set_row_spacings(GTK_TABLE(table),5);
		gtk_table_set_col_spacings(GTK_TABLE(table),5);
		gtk_container_add(GTK_CONTAINER(frame),table);
		button = gtk_button_new_with_label("载入数据");
		gtk_table_attach_defaults(GTK_TABLE(table),button,0,1,0,1);
		g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_load),NULL);

		button = gtk_button_new_with_label("从文件夹中添加数据");
	    gtk_table_attach_defaults(GTK_TABLE(table),button,1,2,0,1);
	    g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_loadfile),NULL);

		button = gtk_button_new_with_label("修改密码");
		gtk_table_attach_defaults(GTK_TABLE(table),button,0,1,1,2);
		g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_change),NULL);

		button = gtk_button_new_with_label("清空数据");
	    gtk_table_attach_defaults(GTK_TABLE(table),button,1,2,1,2);
	    g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(init),NULL);

	    button= gtk_button_new_with_label("显示学生信息");
	    gtk_table_attach_defaults(GTK_TABLE(table),button,0,2,2,3);
	    g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(xianshi),NULL);


	    button= gtk_button_new_with_label("手动添加学生数据");
	    gtk_table_attach_defaults(GTK_TABLE(table),button,0,2,3,4);
	    g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(append_row),NULL);

		button= gtk_button_new_with_label("按学号排序");
	    gtk_table_attach_defaults(GTK_TABLE(table),button,0,1,4,5);
	    g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_sortnum),NULL);

	    button= gtk_button_new_with_label("按名字排序");
	    gtk_table_attach_defaults(GTK_TABLE(table),button,1,2,4,5);
	    g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_sortname),NULL);

	    button= gtk_button_new_with_label("按学号查找数据");
	    gtk_table_attach_defaults(GTK_TABLE(table),button,0,1,5,6);
	    g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_search),NULL);


	    button= gtk_button_new_with_label("按名字查找数据");
	    gtk_table_attach_defaults(GTK_TABLE(table),button,1,2,5,6);
	    g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_search1),NULL);

	    button= gtk_button_new_with_label("删除学生(by学号)");
	    gtk_table_attach_defaults(GTK_TABLE(table),button,0,1,6,7);
	    g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_delnum),NULL);

	    button= gtk_button_new_with_label("删除学生(by名字)");
	    gtk_table_attach_defaults(GTK_TABLE(table),button,1,2,6,7);
	    g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_delname),NULL);

	    button= gtk_button_new_with_label("保存数据");
	    gtk_table_attach_defaults(GTK_TABLE(table),button,0,1,7,8);
	    g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_save),NULL);

	    button= gtk_button_new_with_label("另存数据");
	    gtk_table_attach_defaults(GTK_TABLE(table),button,1,2,7,8);
	    g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_saveas),NULL);

	    button= gtk_button_new_with_label("退出系统");
	    gtk_table_attach_defaults(GTK_TABLE(table),button,0,2,8,9);
	    g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_quit),window);



		gtk_widget_show_all(window);
		return window;
	}


	void on_biao()
{
 biao_window=create_biao_window();
 gtk_widget_show(biao_window);
}


