static int loadchenggong=1;
struct student*loadnew()
{
    struct student*p;
    struct student*p1;
    struct student*p3;
    struct student*p4;
    int n=0,i=0,j=0;
    FILE*fp;
    if((fp=fopen("C:\\data.txt","r"))==NULL)
    {
        printf("bunnengdakaiwenjian!\n");
        loadchenggong=0;
        exit(0);
    }

    else
     {

        head =(struct student *)malloc(sizeof(struct student));
        if(fread(head,sizeof(struct student),1,fp)!=1)
            printf("meiyoushujukeyiduqu!\n\n");
        p=head;
        n++;
        while(!feof(fp))
        {
          p1= (struct student *)malloc(sizeof(struct student));
          fread(p1,sizeof(struct student),1,fp);
          p->next=p1;
          p=p1;
          n++;
        }
        p->next=NULL;
     }
    n--;
    for(p3=head,i=0;p3!=NULL;p3=p3->next) i++;
     for(j=0,p4=head;j<i-2;j++)
     {
         p4=p4->next;
     }
     p4->next=NULL;



printf("ciciduquxueshengshu%d\n\n",n);
shuchu(head);
    fclose(fp);
    return head;
}

