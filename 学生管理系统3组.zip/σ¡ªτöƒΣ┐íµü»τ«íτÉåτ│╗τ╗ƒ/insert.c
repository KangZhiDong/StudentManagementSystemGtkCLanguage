static GtkWidget*zhuce_window;
static GtkWidget*entryx;
static GtkWidget*entrym;
static GtkWidget*entryn;

struct id *insert(struct id *head1)
{ char i;
  struct id *p;
  struct id *p1;
  struct id *p2;

  p2=head1;
  p=(struct id *)malloc(sizeof(struct id));
  shuchumima(head1);
   strcpy(p->zhanghao,gtk_entry_get_text(GTK_ENTRY(entryx)));
   strcpy(p->denglumima,gtk_entry_get_text(GTK_ENTRY(entryn)));


  if(head1==NULL)/*原链表是空表*/
  {
  head1=p;
  p->next=NULL;
  }
  else
  {
  while((strcmp(p->zhanghao,p2->zhanghao)>0)&&(p2->next!=NULL))

  {
    p1=p2;
    p2=p2->next;
   }
  if(strcmp(p->zhanghao,p2->zhanghao)<=0)
  {
  if(p2==head1)/*p2是表头节点，p插入首节点之前*/
  {
  head1=p;
  p->next=p2;
  }
  else
  {
  p1->next=p;
  p->next=p2;
  }
 }
  else
  {
  p2->next=p;
  p->next=NULL;
  }
 }
shuchumima(head1);
printf("charulianbiaole");
savemima(head1);
return(head1);
}
