


void on_search_delete(GtkWidget*window,GdkEvent*event,gpointer data)
{
    gtk_widget_destroy(search_window);
}


void on_searchnum()
{  printf("12345678");
   searchnum(head);
}

GtkWidget*create_search_window()
{
GtkWidget* bbox;
GtkWidget* vbox;
GtkWidget* label;
GtkWidget* window;
GtkWidget* sep;
GtkWidget* button;
GtkWidget* table;
window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
//gtk_widget_set_size_request (window, 300, 350);
gtk_window_set_icon(GTK_WINDOW(window), create_pixbuf("123.jpg"));
g_signal_connect(G_OBJECT(window),"delete_event",G_CALLBACK(on_search_delete),window);
gtk_window_set_title(GTK_WINDOW(window),"按查找学号查询");
gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_CENTER);
gtk_container_set_border_width(GTK_CONTAINER(window),10);
vbox = gtk_vbox_new(FALSE,0);
gtk_container_add(GTK_CONTAINER(window),vbox);
table = gtk_table_new(5,2,FALSE);
gtk_box_pack_start(GTK_BOX(vbox),table,FALSE,FALSE,5);
label = gtk_label_new("输入你要查找学生的学号:");
gtk_table_attach_defaults(GTK_TABLE(table),label,0,1,0,1);
entry_search = gtk_entry_new();
gtk_table_attach_defaults(GTK_TABLE(table),entry_search,1,2,0,1);
sep = gtk_hseparator_new();
gtk_box_pack_start(GTK_BOX(vbox),sep,FALSE,FALSE,5);
bbox = gtk_hbutton_box_new();
gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox),GTK_BUTTONBOX_EDGE);
gtk_box_pack_start(GTK_BOX(vbox),bbox,FALSE,FALSE,5);
button = gtk_button_new_from_stock(GTK_STOCK_FIND);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,25);

g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(chaxuntu),NULL);
g_signal_connect(G_OBJECT(button),"released",G_CALLBACK(on_search_delete),NULL);
button = gtk_button_new_from_stock(GTK_STOCK_CANCEL);
g_signal_connect(GTK_OBJECT(button),"clicked",G_CALLBACK(on_search_delete),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,35);
gtk_widget_show_all(window);
return window;
}


void on_search(GtkButton*button,gpointer data)
{
 search_window=create_search_window();
 gtk_widget_show(search_window);
}
