void   on_ok_clicked   (GtkButton *button,gpointer data)
{
    new_row[0] = gtk_entry_get_text(GTK_ENTRY(entry_num));
    new_row[1] = gtk_entry_get_text(GTK_ENTRY(entry_name));
    new_row[2] = gtk_entry_get_text(GTK_ENTRY(entry_sex));
    new_row[3] = gtk_entry_get_text(GTK_ENTRY(entry_year));
    new_row[4] = gtk_entry_get_text(GTK_ENTRY(entry_month));
    new_row[5] = gtk_entry_get_text(GTK_ENTRY(entry_day));
    new_row[6] = gtk_entry_get_text(GTK_ENTRY(entry_major));
    new_row[7] = gtk_entry_get_text(GTK_ENTRY(entry_banji));
    new_row[8] = gtk_entry_get_text(GTK_ENTRY(entry_adress));
    new_row[9] = gtk_entry_get_text(GTK_ENTRY(entry_dorm));
    new_row[10] = gtk_entry_get_text(GTK_ENTRY(entry_score1));
    new_row[11] = gtk_entry_get_text(GTK_ENTRY(entry_score2));
    new_row[12] = gtk_entry_get_text(GTK_ENTRY(entry_score3));
    new_row[13] = gtk_entry_get_text(GTK_ENTRY(entry_xuefen));
    head=jianli(head);
    shuchu(head);


    row_count++;
    gtk_clist_append(GTK_CLIST(clist),new_row);
    gtk_widget_destroy(add_win);
}
void   on_cancel_clicked  (GtkButton *button,gpointer data)
{
    gtk_widget_destroy(add_win);
}

void guangbi(GtkButton *button,gpointer data)
{
    gtk_widget_destroy(xianshi_win);
}


GtkWidget* create_addwin   (void)
{
    GtkWidget*win;
    GtkWidget* vbox;
GtkWidget* table;
GtkWidget* bbox;
GtkWidget* label;
GtkWidget* button;
win = gtk_window_new(GTK_WINDOW_TOPLEVEL);
gtk_window_set_title(GTK_WINDOW(win),"添加记录");
gtk_window_set_position(GTK_WINDOW(win),GTK_WIN_POS_CENTER);
gtk_window_set_icon(GTK_WINDOW(win), create_pixbuf("123.jpg"));
g_signal_connect(G_OBJECT(win),"delete_event",
         G_CALLBACK(gtk_widget_destroy),win);
gtk_container_set_border_width(GTK_CONTAINER(win),10);
vbox = gtk_vbox_new(FALSE,0);
gtk_container_add(GTK_CONTAINER(win),vbox);
table = gtk_table_new(5,2,FALSE);
gtk_box_pack_start(GTK_BOX(vbox),table,FALSE,FALSE,5);
label = gtk_label_new("学号");
gtk_table_attach_defaults(GTK_TABLE(table),label,0,1,0,1);
entry_num = gtk_entry_new();
gtk_table_attach_defaults(GTK_TABLE(table),entry_num,1,2,0,1);

label = gtk_label_new("姓名");
gtk_table_attach_defaults(GTK_TABLE(table),label,0,1,1,2);
entry_name = gtk_entry_new();
gtk_table_attach_defaults(GTK_TABLE(table),entry_name,1,2,1,2);
label = gtk_label_new("性别");
gtk_table_attach_defaults(GTK_TABLE(table),label,0,1,2,3);
entry_sex = gtk_entry_new();
gtk_table_attach_defaults(GTK_TABLE(table),entry_sex,1,2,2,3);
label=gtk_label_new("年份");
gtk_table_attach_defaults(GTK_TABLE(table),label,0,1,3,4);
entry_year = gtk_entry_new();
gtk_table_attach_defaults(GTK_TABLE(table),entry_year,1,2,3,4);
label = gtk_label_new("月份");
gtk_table_attach_defaults(GTK_TABLE(table),label,0,1,4,5);
entry_month = gtk_entry_new();
gtk_table_attach_defaults(GTK_TABLE(table),entry_month,1,2,4,5);
label = gtk_label_new("日");
gtk_table_attach_defaults(GTK_TABLE(table),label,0,1,5,6);
entry_day = gtk_entry_new();
gtk_table_attach_defaults(GTK_TABLE(table),entry_day,1,2,5,6);
label = gtk_label_new("专业");
gtk_table_attach_defaults(GTK_TABLE(table),label,0,1,6,7);
entry_major = gtk_entry_new();
gtk_table_attach_defaults(GTK_TABLE(table),entry_major,1,2,6,7);
label = gtk_label_new("班级");
gtk_table_attach_defaults(GTK_TABLE(table),label,0,1,7,8);
entry_banji = gtk_entry_new();
gtk_table_attach_defaults(GTK_TABLE(table),entry_banji,1,2,7,8);
label = gtk_label_new("地址");
gtk_table_attach_defaults(GTK_TABLE(table),label,0,1,8,9);
entry_adress = gtk_entry_new();
gtk_table_attach_defaults(GTK_TABLE(table),entry_adress,1,2,8,9);
label = gtk_label_new("宿舍");
gtk_table_attach_defaults(GTK_TABLE(table),label,0,1,9,10);
entry_dorm = gtk_entry_new();
gtk_table_attach_defaults(GTK_TABLE(table),entry_dorm,1,2,9,10);
label = gtk_label_new("语文");
gtk_table_attach_defaults(GTK_TABLE(table),label,0,1,10,11);
entry_score1 = gtk_entry_new();
gtk_table_attach_defaults(GTK_TABLE(table),entry_score1,1,2,10,11);
label = gtk_label_new("数学");
gtk_table_attach_defaults(GTK_TABLE(table),label,0,1,11,12);
entry_score2= gtk_entry_new();
gtk_table_attach_defaults(GTK_TABLE(table),entry_score2,1,2,11,12);
label = gtk_label_new("英语");
gtk_table_attach_defaults(GTK_TABLE(table),label,0,1,12,13);
entry_score3 = gtk_entry_new();
gtk_table_attach_defaults(GTK_TABLE(table),entry_score3,1,2,12,13);
label = gtk_label_new("学分");
gtk_table_attach_defaults(GTK_TABLE(table),label,0,1,13,14);
entry_xuefen = gtk_entry_new();
gtk_table_attach_defaults(GTK_TABLE(table),entry_xuefen,1,2,13,14);
bbox = gtk_hbutton_box_new();
gtk_box_pack_start(GTK_BOX(vbox),bbox,FALSE,FALSE,5);
gtk_box_set_spacing(GTK_BOX(bbox),5);
gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox),GTK_BUTTONBOX_END);
button = gtk_button_new_from_stock(GTK_STOCK_OK);
g_signal_connect(G_OBJECT(button),"clicked",
G_CALLBACK(on_ok_clicked),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,5);
button = gtk_button_new_from_stock(GTK_STOCK_CANCEL);
g_signal_connect(G_OBJECT(button),"clicked",
G_CALLBACK(on_cancel_clicked),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,5);
gtk_widget_show_all(win);
 return win;
 }



void gtk_clist_clear (GtkCList *clist);

GtkWidget* create_button (gchar* stockid)
 {   //创建图像按钮
 GtkWidget *button;
 GtkWidget *image;
 image=gtk_image_new_from_stock(stockid,GTK_ICON_SIZE_MENU);
 button=gtk_button_new();
 gtk_container_add(GTK_CONTAINER(button),image);
 return button;
 }
 void goto_first(GtkButton *button,gpointer data)
 {   //转首行、
 current_row=0;
 gtk_clist_select_row(GTK_CLIST(clist),current_row,0);
 }
 void goto_last(GtkButton *button,gpointer data)
 {   //转尾行、
 current_row=row_count-1;
 gtk_clist_select_row(GTK_CLIST(clist),current_row,0);
 }
 void go_back (GtkButton *button,gpointer data)
 {   //前一行
 current_row--;
 if(current_row==-1)
 return;
 gtk_clist_select_row(GTK_CLIST(clist),current_row,0);
 }
 void go_forward (GtkButton *button,gpointer data)
 {  current_row++;
 if(current_row>row_count)
 return;
 gtk_clist_select_row(GTK_CLIST(clist),current_row,0);
 } //后一行
 void append_row (GtkButton *button,gpointer data)
 {   //添加数据
 add_win=create_addwin();
 gtk_widget_show(add_win);
 }


GtkWidget* create_xianshi_window()
 {
 GtkWidget *window;
 GtkWidget *vbox;
 GtkWidget *bbox;
 GtkWidget *button;
 GtkTooltips *button_tips;
 //gtk_init(&argc,&argv);
 window=gtk_window_new(GTK_WINDOW_TOPLEVEL);
 //g_signal_connect(G_OBJECT(window),"delete_event",G_CALLBACK(gtk_main_quit),NULL);
 g_signal_connect(G_OBJECT(window),"delete_event",G_CALLBACK(guangbi),NULL);
 gtk_window_set_title(GTK_WINDOW(window),"学生管理系统");
 gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_CENTER);
gtk_window_set_icon(GTK_WINDOW(window), create_pixbuf("123.jpg"));
gtk_container_set_border_width(GTK_CONTAINER(window),10);
gtk_widget_set_size_request (window, 1250, 500);
vbox=gtk_vbox_new(FALSE,0);
gtk_container_add(GTK_CONTAINER(window),vbox);
clist=gtk_clist_new_with_titles(14,titles);
gtk_box_pack_start(GTK_BOX(vbox),clist,TRUE,TRUE,5);
bbox=gtk_hbutton_box_new();
button_tips=gtk_tooltips_new();
gtk_box_pack_start(GTK_BOX(vbox),bbox,FALSE,FALSE,5);
gtk_box_set_spacing(GTK_BOX(bbox),5);
gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox),GTK_BUTTONBOX_END);
gtk_button_box_set_child_size(GTK_BUTTON_BOX(bbox),20,20);

shuchuxinxi(head);



button=create_button(GTK_STOCK_GOTO_FIRST);
gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),button,"转到首行","首行");
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(goto_first),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,2);


button=create_button(GTK_STOCK_GO_BACK);
gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),button,"转到前一页","前一页");
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(go_back),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,2);



button=create_button(GTK_STOCK_GO_FORWARD);
gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),button,"转到下一行","下一行");
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(go_forward),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,2);
button=create_button(GTK_STOCK_GOTO_LAST);
gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),button,"转到尾行","尾行");
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(goto_last),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,2);

button=create_button(GTK_STOCK_FILE);
gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),button,"载入","新增");
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_load),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,2);
button=create_button(GTK_STOCK_OPEN);
gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),button,"从文件夹中打开","新增");
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_loadfile),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,2);



button=create_button(GTK_STOCK_ADD);
gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),button,"添加学生","新增");
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(append_row),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,2);


button=create_button(GTK_STOCK_FIND);
gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),button,"按学号查找","查找");
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_search),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,2);
button=create_button(GTK_STOCK_FIND);
gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),button,"按名字查找","查找");
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_search1),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,2);
button=create_button(GTK_STOCK_SORT_ASCENDING);
gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),button,"按学号排序","查找");
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_sortnum),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,2);
button=create_button(GTK_STOCK_SORT_DESCENDING);
gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),button,"按名字排序","排序");
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_sortname),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,2);
button=create_button(GTK_STOCK_FIND_AND_REPLACE);
gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),button,"按学号删除学生","删除");
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_delnum),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,2);
button=create_button(GTK_STOCK_FIND_AND_REPLACE);
gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),button,"按名字删除学生","删除");
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_delname),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,2);
button=create_button(GTK_STOCK_SAVE);
gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),button,"保存","保存");
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_save),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,2);
button=create_button(GTK_STOCK_SAVE_AS);
gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),button,"另存为","保存");
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_saveas),NULL);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,2);


button=create_button(GTK_STOCK_QUIT);
gtk_tooltips_set_tip(GTK_TOOLTIPS(button_tips),button,"退出","退出");
g_signal_connect(G_OBJECT(button),"clicked",G_CALLBACK(on_quit),window);
gtk_box_pack_start(GTK_BOX(bbox),button,FALSE,FALSE,5);
gtk_widget_show_all(window);
//gtk_main();
return window;
 }
 void xianshi ()
 {   //添加数据
 xianshi_win=create_xianshi_window();
 gtk_widget_show(xianshi_win);
 }
